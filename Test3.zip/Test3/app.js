
    var x = "";
    var i, j;
        fetch('https://raw.githubusercontent.com/atesfay/JSON/master/sample.json').then(function (response) {
            return response.json();
        }).then(function (data) {
            var myObj = data;
            for (i in myObj) {
        x += '' +
        '<div class="bx--row" style="margin: 0.2rem 0.0rem;padding: 1rem 2.4rem">' +
        '<button class="bx--btn bx--btn--primary" type="button" data-modal-target="#modal-4x6k9ihqa1h">' + myObj[i].Full_Name +
        '<div style="padding-top: 2rem">' +
        '<img src="accordion.png" alt="Accordion" width="200" height="200">' +
        '</div>' +
        '</button>'
                // x += "<h1> Full Name: " + myObj[i].Full_Name + "</h1>";
                // x += "<h2> Background Image File " + myObj[i].backgroundImg + "</h2>";
                for (j in myObj[i].detial_info) {
        x += '' +
        ' <div data-modal id="modal-4x6k9ihqa1h" class="bx--modal " role="dialog" aria-modal="true"' +
        'aria-labelledby="modal-4x6k9ihqa1h-label" aria-describedby="modal-4x6k9ihqa1h-heading" tabindex="-1">' +
        '<div class="bx--modal-container">' +
        '<div class="bx--modal-header">' +
        '<p class="bx--modal-header__label bx--type-delta" id="modal-4x6k9ihqa1h-label">' + myObj[i].Full_Name + '</p>' +
        '<p class="bx--modal-header__heading bx--type-beta" id="modal-4x6k9ihqa1h-heading">' + myObj[i].detial_info[j].sub_Title + '</p>' +
        '<button class="bx--modal-close" type="button" data-modal-close aria-label="close modal">' +
        '<svg focusable="false" preserveAspectRatio="xMidYMid meet" style="will-change: transform;"' +
        'xmlns="http://www.w3.org/2000/svg" class="bx--modal-close__icon" width="16" height="16"' +
        'viewBox="0 0 16 16" aria-hidden="true">' +
        '<path d="M12 4.7l-.7-.7L8 7.3 4.7 4l-.7.7L7.3 8 4 11.3l.7.7L8 8.7l3.3 3.3.7-.7L8.7 8z"></path>' +
        '</svg>' +
        '</button>' +
        '</div>' +

        '<div class="bx--modal-content">' +
        '<p>' + myObj[i].detial_info[j].description + '</p>' +
        '<p>' + myObj[i].detial_info[j].a_url_Link + '</p>' +
        ' </div>' +

        '<div class="bx--modal-footer">' +
        '<button class="bx--btn bx--btn--secondary" type="button" data-modal-close>Secondary button</button>' +
        '<button class="bx--btn bx--btn--primary" type="button" data-modal-primary-focus>Primary button</button>' +
        '</div>'
                    '</div>'
    '</div>'

                    // x += "<h3> Sub Title: " + myObj[i].detial_info[j].sub_Title + "</h3>";
                    // x += "<h5> Description: " + myObj[i].detial_info[j].description + "</h5>";
                    // x += "<h6> URL Link: " + myObj[i].detial_info[j].a_url_Link + "</h6>";
                }
            }
            document.getElementById("demo").innerHTML = x;//myObj.Full_Name;
        });
 